package Assignment.HelloWorld;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_TEXT = "Assignment.HelloWorld.EXTRA_TEXT";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Button to Second Activity
        Button button_1 = (Button) findViewById(R.id.Button_1);
        button_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity_2();
            }
        });

    }

        private void openActivity_2() {
            EditText editText_4 = (EditText) findViewById(R.id.EditText_4);
            String text = editText_4.getText().toString();

            Intent intent = new Intent(MainActivity.this, Activity_2.class);
            intent.putExtra(EXTRA_TEXT, text);
            startActivity(intent);
        }

}
